export default {
  jwt: {
    secret: 'c9c35cf409344312146fa7546a94d1a6',
    expiresIn: '30d',
  },
};
